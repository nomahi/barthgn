# ============================================================
# exact_hgn: Conditional Logistic Meta-Analysis (Binary Outcomes)
#   Wald test/CI added to exact_hgn_fixed() and exact_hgn_RE()
# ============================================================

## ---------- NSE helper (metafor-like data=) ----------
.get_vec <- function(arg, data) {
  if (missing(arg)) stop("Required argument is missing.")
  if (!missing(data)) {
    a <- substitute(arg)
    if (is.symbol(a)) {
      nm <- deparse(a)
      if (nm %in% names(data)) return(data[[nm]])
    }
  }
  eval.parent(substitute(arg))
}

`%||%` <- function(a, b) if (is.null(a)) b else a
.logsumexp <- function(v) { m <- max(v); m + log(sum(exp(v - m))) }
.pval_fmt <- function(p){
  if (!is.finite(p)) return("NA")
  if (p < 1e-12) return("<1e-12")
  if (p < 0.001) return(sprintf("%.1e", p))
  sprintf("%.4f", p)
}

## small numeric helpers (NEW) ------------------------------
.qnorm_ <- function(p) stats::qnorm(p)
.pnorm_ <- function(z) stats::pnorm(z)
# central second derivative with safety checks
.second_deriv <- function(f, x, h=1e-4, ..., max_iter=4){
  # try reducing h if curvature looks unstable
  for (i in 0:max_iter){
    hh <- h / (2^i)
    fxph <- f(x + hh, ...)
    fx   <- f(x, ...)
    fxmh <- f(x - hh, ...)
    if (is.finite(fxph) && is.finite(fx) && is.finite(fxmh)){
      return( (fxph - 2*fx + fxmh) / (hh*hh) )
    }
  }
  return(NA_real_)
}

## ---------- meta input -> strata sufficient stats ----------
.build_tab_from_meta <- function(d1, n1, d2, n2, data) {
  v_d1 <- .get_vec(d1, data); v_n1 <- .get_vec(n1, data)
  v_d2 <- .get_vec(d2, data); v_n2 <- .get_vec(n2, data)
  stopifnot(is.numeric(v_d1), is.numeric(v_n1), is.numeric(v_d2), is.numeric(v_n2))
  if (anyNA(c(v_d1, v_n1, v_d2, v_n2))) stop("NA in input counts.")
  if (any(v_n1 <= 0 | v_n2 <= 0)) stop("Totals must be positive.")
  if (any(v_d1 < 0 | v_d2 < 0))   stop("Events must be nonnegative.")
  if (any(v_d1 > v_n1 | v_d2 > v_n2)) stop("Events cannot exceed totals.")
  n <- v_n1 + v_n2
  m <- v_d1 + v_d2
  t <- v_n1
  kobs <- v_d1
  data.frame(n=n, m=m, t=t, kobs=kobs, stringsAsFactors = FALSE)
}

## ---------- exact conditional pieces ----------
.stratum_norm_logZ <- function(beta, n, m, t){
  kmin <- max(0, m - (n - t)); kmax <- min(m, t)
  if (kmax < kmin) return(-Inf)
  k <- kmin:kmax
  a <- lchoose(t, k) + lchoose(n - t, m - k) + beta * k
  .logsumexp(a)
}

.logLik_stratum <- function(beta, n, m, t, kobs){
  if (m==0 || m==n || t==0 || t==n) return(0) # uninformative stratum
  beta * kobs - .stratum_norm_logZ(beta, n, m, t)
}

.stratum_moments <- function(beta, n, m, t){
  if (m==0 || m==n || t==0 || t==n) return(list(Ek=NA_real_, Vk=0))
  kmin <- max(0, m - (n - t)); kmax <- min(m, t)
  k <- kmin:kmax
  a <- lchoose(t, k) + lchoose(n - t, m - k) + beta * k
  logZ <- .logsumexp(a)
  pk <- exp(a - logZ)
  Ek <- sum(k * pk)
  Vk <- sum(k^2 * pk) - Ek^2
  list(Ek=Ek, Vk=Vk)
}

## ---------- Gauss–Hermite nodes/weights ----------
.get_GH <- function(Q = 30){
  if (requireNamespace("statmod", quietly = TRUE)) {
    gh_fun <- getExportedValue("statmod", "gauss.quad.prob")
    gh <- gh_fun(Q, dist = "normal")
    return(list(x = gh$nodes, w = gh$weights))
  } else {
    z <- seq(-5, 5, length.out = Q)
    w <- stats::dnorm(z)
    w <- w / sum(w)
    return(list(x = z, w = w))
  }
}

## ---------- marginal likelihoods (random effects) ----------
.marginal_loglik <- function(mu, sigma, tab, gh){
  if (!(is.finite(sigma) && sigma > 0)) return(-Inf)
  x <- gh$x; w <- gh$w
  ll_sum <- 0
  inf <- with(tab, (m > 0 & m < n & t > 0 & t < n))
  idx <- which(inf)
  if (!length(idx)) return(0)
  for (i in idx){
    n <- tab$n[i]; m <- tab$m[i]; t <- tab$t[i]; kobs <- tab$kobs[i]
    log_terms <- vapply(x, function(zj){
      beta <- mu + sigma * zj
      .logLik_stratum(beta, n, m, t, kobs)
    }, numeric(1))
    ll_sum <- ll_sum + .logsumexp(log(w) + log_terms)
  }
  ll_sum
}

.restricted_loglik_mu <- function(mu0, tab, gh, start_log_sigma = -1){
  obj <- function(logsig) - .marginal_loglik(mu0, exp(logsig), tab, gh)
  opt <- tryCatch(optim(start_log_sigma, obj, method="Brent", lower=-6, upper=3),
                  error = function(e) NULL)
  if (is.null(opt)) {
    list(mu=mu0, sigma_hat=NA_real_, logLik=NA_real_, converged=FALSE, message="optim error")
  } else {
    list(mu=mu0, sigma_hat=exp(opt$par), logLik = -opt$value,
         converged = (opt$convergence==0), message="%||%"(opt$message, ""))
  }
}

.fit_full_marginal <- function(tab, gh, start_mu=0, start_log_sigma=-1){
  nll <- function(theta) - .marginal_loglik(theta[1], exp(theta[2]), tab, gh)
  opt <- tryCatch(optim(c(start_mu, start_log_sigma), nll, method="BFGS",
                        control=list(reltol=1e-8)),
                  error=function(e) NULL)
  if (is.null(opt)) {
    list(mu=NA_real_, sigma=NA_real_, logLik=NA_real_, converged=FALSE, message="optim error")
  } else {
    list(mu=opt$par[1], sigma=exp(opt$par[2]), logLik=-opt$value,
         converged=(opt$convergence==0), message="%||%"(opt$message,""))
  }
}

.fixed_loglik_mu <- function(mu, tab){
  ll <- 0
  inf <- with(tab, (m > 0 & m < n & t > 0 & t < n))
  idx <- which(inf)
  if (!length(idx)) return(0)
  for (i in idx){
    ll <- ll + .logLik_stratum(mu, tab$n[i], tab$m[i], tab$t[i], tab$kobs[i])
  }
  ll
}
.fit_fixed_mu <- function(tab, lower=-10, upper=10, init=0){
  obj <- function(mu) - .fixed_loglik_mu(mu, tab)
  opt <- tryCatch(optim(init, obj, method="Brent", lower=lower, upper=upper),
                  error=function(e) NULL)
  if (is.null(opt)) {
    list(mu_hat=NA_real_, logLik=NA_real_, converged=FALSE, message="optim error")
  } else {
    list(mu_hat=opt$par, logLik=-opt$value, converged=(opt$convergence==0),
         message="%||%"(opt$message,""))
  }
}

## ---------- posterior moments via GH (RE) ----------
.posterior_moments4_stratum <- function(mu, sigma, n, m, t, kobs, gh){
  if (m==0 || m==n || t==0 || t==n) return(c(m1=mu, v1=0, m2=0, m4=0))
  x <- gh$x; w <- gh$w
  betas <- mu + sigma * x
  logL  <- vapply(betas, function(b) .logLik_stratum(b, n, m, t, kobs), numeric(1))
  logw  <- log(w) + logL
  logZ  <- .logsumexp(logw)
  pj    <- exp(logw - logZ)
  m1    <- sum(pj * betas)
  v1    <- sum(pj * (betas - m1)^2)
  m2c   <- sum(pj * (betas - mu)^2)
  m4c   <- sum(pj * (betas - mu)^4)
  c(m1=m1, v1=v1, m2=m2c, m4=m4c)
}

## ===========================================================
##                PUBLIC: FITTERS (metafor-like)
## ===========================================================
# exact_hgn_fixed: sigma = 0  (Wald test/CI added)
exact_hgn_fixed <- function(d1, n1, d2, n2, data, conf_level=0.95){
  tab <- .build_tab_from_meta(d1, n1, d2, n2, data)
  fit <- .fit_fixed_mu(tab)

  # Wald SE from information: I(mu) = sum Var_beta(K_i) at beta = mu
  se_mu <- NA_real_; ci <- c(NA_real_, NA_real_); z <- NA_real_; p <- NA_real_
  or_ci <- c(NA_real_, NA_real_)
  if (isTRUE(fit$converged) && is.finite(fit$mu_hat)) {
    Vk_sum <- 0
    inf <- with(tab, (m>0 & m<n & t>0 & t<n))
    for (i in which(inf)){
      mom <- .stratum_moments(fit$mu_hat, tab$n[i], tab$m[i], tab$t[i])
      Vk_sum <- Vk_sum + mom$Vk
    }
    if (Vk_sum > 0) {
      se_mu <- 1/sqrt(Vk_sum)
      alpha <- 1 - conf_level
      zc <- .qnorm_(1 - alpha/2)
      ci <- c(fit$mu_hat - zc*se_mu, fit$mu_hat + zc*se_mu)
      z <- (fit$mu_hat - 0)/se_mu
      p <- 2*(1 - .pnorm_(abs(z)))
      or_ci <- exp(ci)
    }
  }

  out <- list(
    model="fixed", mu=fit$mu_hat, sigma=0, tau2=0, logLik=fit$logLik,
    converged=fit$converged, message=fit$message, strata_table=tab,
    se_mu = se_mu,
    wald_mu = list(z=z, p_value=p, conf_level=conf_level, ci=ci, OR_CI=or_ci)
  )
  class(out) <- "clogit_meta_fit"
  out
}

# exact_hgn_RE: beta_s ~ N(mu, sigma^2)  (Wald test/CI added for mu)
exact_hgn_RE <- function(d1, n1, d2, n2, data=NULL, gh_points=30, start_mu=0, start_log_sigma=-1,
                         conf_level=0.95){
	if(is.null(data)==FALSE){
		data <- data.frame(data)
		d1 <- data[, deparse(substitute(d1))]
		n1 <- data[, deparse(substitute(n1))]
		d2 <- data[, deparse(substitute(d2))]
		n2 <- data[, deparse(substitute(n2))]
	}
 
  tab <- .build_tab_from_meta(d1, n1, d2, n2, data)
  gh <- .get_GH(gh_points)
  fit <- .fit_full_marginal(tab, gh, start_mu, start_log_sigma)

  # Wald SE for mu via curvature of marginal loglik wrt mu (sigma fixed at MLE)
  se_mu <- NA_real_; ci <- c(NA_real_, NA_real_); z <- NA_real_; p <- NA_real_
  or_ci <- c(NA_real_, NA_real_)
  if (isTRUE(fit$converged) && is.finite(fit$mu) && is.finite(fit$sigma) && fit$sigma>0){
    fmu <- function(mu) .marginal_loglik(mu, fit$sigma, tab, gh)
    d2 <- .second_deriv(fmu, fit$mu, h=1e-3)
    if (is.finite(d2) && d2 < 0){ # concave as expected
      info <- -d2
      se_mu <- 1/sqrt(info)
      alpha <- 1 - conf_level
      zc <- .qnorm_(1 - alpha/2)
      ci <- c(fit$mu - zc*se_mu, fit$mu + zc*se_mu)
      z <- (fit$mu - 0)/se_mu
      p <- 2*(1 - .pnorm_(abs(z)))
      or_ci <- exp(ci)
    }
  }

  out <- list(
    model="random", mu=fit$mu, sigma=fit$sigma, tau2=fit$sigma^2,
    logLik=fit$logLik, converged=fit$converged, message=fit$message,
    strata_table=tab, gh_points=length(gh$x),
    se_mu = se_mu,
    wald_mu = list(z=z, p_value=p, conf_level=conf_level, ci=ci, OR_CI=or_ci)
  )
  class(out) <- "clogit_meta_fit"
  out
}

## ===========================================================
##                PUBLIC: TESTS (LRT)  [unchanged]
## ===========================================================
LRT_mu_fixed <- function(d1, n1, d2, n2, data, mu0=0){
  tab <- .build_tab_from_meta(d1, n1, d2, n2, data)
  full <- .fit_fixed_mu(tab)
  ll0  <- .fixed_loglik_mu(mu0, tab)
  LR <- 2 * (full$logLik - ll0)
  p  <- pchisq(LR, df=1, lower.tail = FALSE)
  out <- list(test="LR (fixed mu)", hypothesis=sprintf("H0: mu = %.6g", mu0),
              statistic=as.numeric(LR), df=1, p_value=p,
              components=list(full=full, restricted=list(mu=mu0, logLik=ll0)))
  class(out) <- "clogit_meta_test"
  out
}

LRT_mu_RE <- function(d1, n1, d2, n2, data=NULL, mu0=0, gh_points=30,
                      start_mu=0, start_log_sigma=-1, restr_log_sigma=-1){
	if(is.null(data)==FALSE){
		data <- data.frame(data)
		d1 <- data[, deparse(substitute(d1))]
		n1 <- data[, deparse(substitute(n1))]
		d2 <- data[, deparse(substitute(d2))]
		n2 <- data[, deparse(substitute(n2))]
	}
 
  tab <- .build_tab_from_meta(d1, n1, d2, n2, data)
  gh  <- .get_GH(gh_points)
  full  <- .fit_full_marginal(tab, gh, start_mu, start_log_sigma)
  restr <- .restricted_loglik_mu(mu0, tab, gh, start_log_sigma = restr_log_sigma)
  LR <- 2 * (full$logLik - restr$logLik)
  p  <- pchisq(LR, df=1, lower.tail=FALSE)
  out <- list(test="LR (RE mu)", hypothesis=sprintf("H0: mu = %.6g", mu0),
              statistic=as.numeric(LR), df=1, p_value=p,
              components=list(full=full, restricted=restr, gh_points=length(gh$x)))
  class(out) <- "clogit_meta_test"
  out
}

LRT_tau2_RE <- function(d1, n1, d2, n2, data, gh_points=30, start_mu=0, start_log_sigma=-1){
  tab <- .build_tab_from_meta(d1, n1, d2, n2, data)
  gh  <- .get_GH(gh_points)
  full  <- .fit_full_marginal(tab, gh, start_mu, start_log_sigma)
  restr <- .fit_fixed_mu(tab)  # sigma=0
  LR <- 2 * (full$logLik - restr$logLik)
  p_mix <- 0.5 * pchisq(LR, df=1, lower.tail = FALSE)  # 0.5*Chi0 + 0.5*Chi1
  out <- list(test="LR (RE variance, boundary)",
              hypothesis="H0: tau2 = 0 (mixture 0.5*Chi0 + 0.5*Chi1)",
              statistic=as.numeric(LR), df="mixture", p_value=p_mix,
              components=list(full=full, restricted_fixed=restr, gh_points=length(gh$x)))
  class(out) <- "clogit_meta_test"
  out
}

## ===========================================================
##                PUBLIC: ESTIMATORS (wrappers) [mu0対応版]
## ===========================================================
## ===========================================================
##                PUBLIC: ESTIMATORS (wrappers) [mu0対応+test選択]
## ===========================================================
EST_mu_fixed <- function(d1, n1, d2, n2, data, mu0=NULL, test=c("wald","score")){
  test <- match.arg(test)
  fit <- exact_hgn_fixed(d1, n1, d2, n2, data)
  if (is.null(mu0)){
    return(list(mu_hat = fit$mu, se = fit$se_mu, logLik = fit$logLik,
                converged = fit$converged, model="fixed", method="estimate"))
  } else if (test == "wald"){
    # Wald z and p for H0: mu=mu0
    se <- fit$se_mu
    z  <- if (is.finite(se) && se>0) (fit$mu - mu0)/se else NA_real_
    p  <- if (is.finite(z)) 2*(1 - pnorm(abs(z))) else NA_real_
    return(list(mu_hat = fit$mu, se = se, logLik = fit$logLik,
                converged = fit$converged, model="fixed",
                mu0=mu0, method="wald", z=z, statistic=z, p_value=p))
  } else { # test == "score"
    # スコア検定: U(mu0)^2 / I(mu0), where I(mu0) = - l''(mu0)
    tab <- .build_tab_from_meta(d1, n1, d2, n2, data)
    ll_fun <- function(mu) .fixed_loglik_mu(mu, tab)
    U <- .nth_deriv_safe(ll_fun, mu0, n=1)
    I <- - .nth_deriv_safe(ll_fun, mu0, n=2)
    S <- if (is.finite(U) && is.finite(I) && I>0) (U*U)/I else NA_real_
    p <- if (is.finite(S)) pchisq(S, df=1, lower.tail=FALSE) else NA_real_
    return(list(mu_hat = fit$mu, se = fit$se_mu, logLik = fit$logLik,
                converged = fit$converged, model="fixed",
                mu0=mu0, method="score", score=S, statistic=S, p_value=p,
                U=U, I=I))
  }
}

EST_mu_RE <- function(d1, n1, d2, n2, data=NULL, gh_points=30,
                      start_mu=0, start_log_sigma=-1, mu0=NULL, 
                      restr_log_sigma=-1){
	if(is.null(data)==FALSE){
		data <- data.frame(data)
		d1 <- data[, deparse(substitute(d1))]
		n1 <- data[, deparse(substitute(n1))]
		d2 <- data[, deparse(substitute(d2))]
		n2 <- data[, deparse(substitute(n2))]
	}
  
    # REのスコア検定：sigmaはH0下のrestricted MLEで固定
    tab <- .build_tab_from_meta(d1, n1, d2, n2)
    gh  <- .get_GH(gh_points)
    restr <- .restricted_loglik_mu(mu0, tab, gh, start_log_sigma = restr_log_sigma)
    if (!is.finite(restr$sigma_hat) || restr$sigma_hat <= 0){
      return(list(model="random",
                  mu0=mu0, method="score", score=NA_real_, statistic=NA_real_, p_value=NA_real_,
                  note="restricted sigma not available / non-finite"))
    }
    ll_fun <- function(mu) .marginal_loglik(mu, restr$sigma_hat, tab, gh)
    U <- .nth_deriv_safe(ll_fun, mu0, n=1)
    I <- - .nth_deriv_safe(ll_fun, mu0, n=2)
    S <- if (is.finite(U) && is.finite(I) && I>0) (U*U)/I else NA_real_
    p <- if (is.finite(S)) pchisq(S, df=1, lower.tail=FALSE) else NA_real_
  out <- list(test="Score (RE mu)", hypothesis=sprintf("H0: mu = %.6g", mu0),
              statistic=S, df=1, p_value=p, U=U, I=I, sigma_H0=restr$sigma_hat)
  class(out) <- "clogit_meta_test"
  out
}

EST_tau2_RE <- function(d1, n1, d2, n2, data, gh_points=30, start_mu=0, start_log_sigma=-1){
  fit <- exact_hgn_RE(d1, n1, d2, n2, data, gh_points, start_mu, start_log_sigma)
  list(tau2_hat = fit$tau2, sigma_hat = fit$sigma, mu_hat = fit$mu,
       logLik = fit$logLik, converged = fit$converged, model="random")
}

## ===========================================================
##                S3: print / summary (extended a bit)
## ===========================================================
print.clogit_meta_fit <- function(x, ...){
  cat("Conditional logistic meta-analysis (binary)\n")
  cat(sprintf("  model: %s\n", x$model))
  if (x$model=="fixed") {
    cat(sprintf("  mu = %.6f\n", x$mu))
    cat(sprintf("  logLik = %.3f, converged: %s\n", x$logLik, x$converged))
  } else {
    cat(sprintf("  mu = %.6f, sigma = %.6f (tau2 = %.6f)\n", x$mu, x$sigma, x$tau2))
    cat(sprintf("  logLik = %.3f, GH points = %s, converged: %s\n",
                x$logLik, x$gh_points %||% NA_integer_, x$converged))
  }
  if (!isTRUE(x$converged)) cat(sprintf("  note: %s\n", x$message %||% ""))
  # Show Wald summary if available
  if (!is.null(x$se_mu) && is.finite(x$se_mu)){
    wm <- x$wald_mu
    cat(sprintf("  Wald mu: z = %.4f, p = %s\n", wm$z, .pval_fmt(wm$p_value)))
    cat(sprintf("           %g%% CI: [%.6f, %.6f]  (OR CI: [%.6f, %.6f])\n",
                wm$conf_level*100, wm$ci[1], wm$ci[2], wm$OR_CI[1], wm$OR_CI[2]))
  }
  invisible(x)
}

summary.clogit_meta_fit <- function(object, ...){
  print(object, ...)
  cat("\nStrata (trials) summary:\n")
  tab <- object$strata_table
  cat(sprintf("  trials: %d, informative: %d\n",
              nrow(tab), sum(with(tab, (m>0 & m<n & t>0 & t<n)))))
  invisible(object)
}

print.clogit_meta_test <- function(x, ...){
  cat(sprintf("%s\n", x$test))
  cat(sprintf("  %s\n", x$hypothesis))
  cat(sprintf("  statistic: %s", ifelse(is.null(x$statistic), "NA", sprintf("%.4f", x$statistic))))
  cat(sprintf(", df: %s", as.character(x$df))); cat(sprintf(", p-value: %s\n", .pval_fmt(x$p_value)))
  if (!is.null(x$components$note)) cat(sprintf("  note: %s\n", x$components$note))
  invisible(x)
}

summary.clogit_meta_test <- function(object, ...){
  print(object, ...)
  if (!is.null(object$components$restricted_fixed)) {
    cat("  (boundary LRT; mixture p-value reported)\n")
  }
  invisible(object)
}






## ===========================================================
##  Bartlett / Bartlett-type corrections (NEW functions only)
##  - minimal intrusion: no changes to existing functions
## ===========================================================

# ---- numeric derivatives (central differences) ----
.nth_deriv_safe <- function(f, x, n=1, h=1e-3, max_iter=4, ...) {
  stopifnot(n %in% 1:4)
  for (i in 0:max_iter){
    hh <- h / (2^i)
    fx2p <- f(x + 2*hh, ...)
    fx1p <- f(x + hh, ...)
    fx0  <- f(x, ...)
    fx1m <- f(x - hh, ...)
    fx2m <- f(x - 2*hh, ...)
    if (!all(is.finite(c(fx2p, fx1p, fx0, fx1m, fx2m)))) next
    if (n==1){
      return( (fx1p - fx1m) / (2*hh) )
    } else if (n==2){
      return( (fx1p - 2*fx0 + fx1m) / (hh*hh) )
    } else if (n==3){
      # 3rd derivative: (f(x+2h) - 2 f(x+h) + 2 f(x-h) - f(x-2h)) / (2 h^3)
      return( (fx2p - 2*fx1p + 2*fx1m - fx2m) / (2*hh^3) )
    } else { # n==4
      # 4th derivative: (f(x+2h) - 4 f(x+h) + 6 f(x) - 4 f(x-h) + f(x-2h)) / h^4
      return( (fx2p - 4*fx1p + 6*fx0 - 4*fx1m + fx2m) / (hh^4) )
    }
  }
  return(NA_real_)
}

# ---- helpers: cumulants from log-lik derivatives at mu0 ----
# returns list(k2, k3, k4, ok)
._bartlett_cumulants_from_ll <- function(ll_fun, mu0){
  d1 <- .nth_deriv_safe(ll_fun, mu0, n=1)
  d2 <- .nth_deriv_safe(ll_fun, mu0, n=2)
  d3 <- .nth_deriv_safe(ll_fun, mu0, n=3)
  d4 <- .nth_deriv_safe(ll_fun, mu0, n=4)
  if (!all(is.finite(c(d1,d2,d3,d4)))) {
    return(list(k2=NA_real_, k3=NA_real_, k4=NA_real_, ok=FALSE, d1=d1, d2=d2, d3=d3, d4=d4))
  }
  k2 <- -d2
  k3 <- -d3
  k4 <- d4 + 3 * k2^2
  list(k2=k2, k3=k3, k4=k4, ok=all(is.finite(c(k2,k3,k4))), d1=d1, d2=d2, d3=d3, d4=d4)
}

# ---- Bartlett factor 'a' from cumulants (1 df) ----
._bartlett_a_1df <- function(k2, k3, k4){
  if (!is.finite(k2) || k2 <= 0) return(NA_real_)
  a <- (k4 / (12 * k2^2)) - (k3^2 / (36 * k2^3))
  a
}

# ===========================================================
# 1) LRT with Bartlett correction (fixed mu)
# ===========================================================
LRT_mu_fixed_Bartlett <- function(d1, n1, d2, n2, data, mu0=0){
  tab <- .build_tab_from_meta(d1, n1, d2, n2, data)
  full <- .fit_fixed_mu(tab)
  ll0  <- .fixed_loglik_mu(mu0, tab)
  LR   <- 2 * (full$logLik - ll0)
  p_raw <- pchisq(LR, df=1, lower.tail = FALSE)

  ll_fun <- function(mu) .fixed_loglik_mu(mu, tab)
  cm <- ._bartlett_cumulants_from_ll(ll_fun, mu0)
  a  <- ._bartlett_a_1df(cm$k2, cm$k3, cm$k4)
  LR_adj <- if (is.finite(a)) LR / (1 + a) else NA_real_
  p_adj  <- if (is.finite(LR_adj)) pchisq(LR_adj, df=1, lower.tail = FALSE) else NA_real_

  # --- for printer compatibility (use adjusted if available) ---
  stat_show <- if (is.finite(LR_adj)) LR_adj else LR
  p_show    <- if (is.finite(LR_adj)) p_adj  else p_raw

  out <- list(
    test="LR (fixed mu) with Bartlett correction",
    hypothesis=sprintf("H0: mu = %.6g", mu0),
    statistic=as.numeric(stat_show),         # <- added
    p_value=p_show,                          # <- added
    statistic_raw=as.numeric(LR),
    p_raw=p_raw,
    statistic_adj=as.numeric(LR_adj),
    p_adj=p_adj,
    components=list(k2=cm$k2, k3=cm$k3, k4=cm$k4, a=a,
                    full=full, ll0=ll0, note=if (!cm$ok) "derivative not stable" else NULL)
  )
  class(out) <- "clogit_meta_test"
  out
}

# ===========================================================
# 2) LRT with Bartlett correction (RE mu)
# ===========================================================
## ====== Add these two helpers (unique names; no collisions) ======
.mb_stratum_rawmom_RE <- function(mu0, sigma0, n, m, t, gh){
  # Returns raw moments M1..M4 of K under the RE mixture at (mu0, sigma0)
  if (m==0 || m==n || t==0 || t==n) return(c(M1=NA_real_, M2=0, M3=0, M4=0))
  x <- gh$x; w <- gh$w
  kmin <- max(0, m - (n - t)); kmax <- min(m, t); k <- kmin:kmax
  M1 <- M2 <- M3 <- M4 <- 0
  for (j in seq_along(x)){
    beta <- mu0 + sigma0 * x[j]
    logw <- lchoose(t, k) + lchoose(n - t, m - k) + beta * k
    logZ <- .logsumexp(logw)
    p <- exp(logw - logZ)
    M1 <- M1 + w[j] * sum(k    * p)
    M2 <- M2 + w[j] * sum(k^2  * p)
    M3 <- M3 + w[j] * sum(k^3  * p)
    M4 <- M4 + w[j] * sum(k^4  * p)
  }
  c(M1=M1, M2=M2, M3=M3, M4=M4)
}

.mb_cumulants_RE_from_moments <- function(tab, mu0, sigma0, gh){
  # Sum of per-stratum cumulants under H0: mu=mu0, sigma=sigma0
  inf <- with(tab, (m>0 & m<n & t>0 & t<n))
  k2 <- k3 <- k4 <- 0
  idx <- which(inf)
  if (!length(idx)) return(list(k2=0, k3=0, k4=0))
  for (i in idx){
    rm <- .mb_stratum_rawmom_RE(mu0, sigma0, tab$n[i], tab$m[i], tab$t[i], gh)
    E  <- rm["M1"]
    V  <- rm["M2"] - E^2
    cm3 <- rm["M3"] - 3*rm["M2"]*E + 2*E^3
    m4  <- rm["M4"] - 4*rm["M3"]*E + 6*rm["M2"]*E^2 - 3*E^4
    cm4 <- m4 - 3*V^2
    k2 <- k2 + V; k3 <- k3 + cm3; k4 <- k4 + cm4
  }
  list(k2=k2, k3=k3, k4=k4)
}

## ====== Drop-in replacement (same signature, same return fields) ======
LRT_mu_RE_Bartlett <- function(d1, n1, d2, n2, data=NULL, mu0=0,
                               gh_points=30, start_mu=0, start_log_sigma=-1,
                               restr_log_sigma=-1, a_cap=0.30, k2_min=1e-6){

  # --- keep data= handling consistent with your current API ---
  if (is.null(data)==FALSE){
    data <- data.frame(data)
    d1 <- data[, deparse(substitute(d1))]
    n1 <- data[, deparse(substitute(n1))]
    d2 <- data[, deparse(substitute(d2))]
    n2 <- data[, deparse(substitute(n2))]
  }

  tab <- .build_tab_from_meta(d1, n1, d2, n2, data)
  gh  <- .get_GH(gh_points)

  # full and restricted fits as in your original function
  full  <- .fit_full_marginal(tab, gh, start_mu, start_log_sigma)
  restr <- .restricted_loglik_mu(mu0, tab, gh, start_log_sigma = restr_log_sigma)

  LR    <- 2 * (full$logLik - restr$logLik)
  p_raw <- pchisq(LR, df=1, lower.tail=FALSE)

  # If restricted sigma is invalid, fall back to raw LR (same behavior)
  if (!is.finite(restr$sigma_hat) || restr$sigma_hat <= 0){
    stat_show <- LR; p_show <- p_raw
    out <- list(
      test="LR (RE mu) with Bartlett correction (moment-based)",
      hypothesis=sprintf("H0: mu = %.6g", mu0),
      statistic=as.numeric(stat_show), p_value=p_show,
      statistic_raw=as.numeric(LR), p_raw=p_raw,
      statistic_adj=NA_real_, p_adj=NA_real_,
      components=list(k2=NA_real_, k3=NA_real_, k4=NA_real_, a=NA_real_,
                      full=full, restricted=restr, gh_points=length(gh$x),
                      note="restricted sigma not available / non-finite")
    )
    class(out) <- "clogit_meta_test"
    return(out)
  }

  # --- compute cumulants via expected-moment sums under H0 ---
  cm <- .mb_cumulants_RE_from_moments(tab, mu0, restr$sigma_hat, gh)
  k2 <- cm$k2; k3 <- cm$k3; k4 <- cm$k4

  # guard rails
  note <- NULL
  if (!is.finite(k2) || k2 <= k2_min){
    a <- NA_real_; LR_adj <- NA_real_; p_adj <- NA_real_
    note <- "k2 too small; used raw LR"
  } else {
    a <- ._bartlett_a_1df(k2, k3, k4)
    if (is.finite(a)){
      if (is.finite(a_cap)) a <- pmin(a, a_cap)
      LR_adj <- LR / (1 + a)
      p_adj  <- pchisq(LR_adj, df=1, lower.tail=FALSE)
    } else {
      LR_adj <- NA_real_; p_adj <- NA_real_; note <- "a not finite; used raw LR"
    }
  }

  stat_show <- if (is.finite(LR_adj)) LR_adj else LR
  p_show    <- if (is.finite(LR_adj)) p_adj  else p_raw

  out <- list(
    test="LR (RE mu) with Bartlett correction (moment-based)",
    hypothesis=sprintf("H0: mu = %.6g", mu0),
    statistic=as.numeric(stat_show), p_value=p_show,
    statistic_raw=as.numeric(LR), p_raw=p_raw,
    statistic_adj=as.numeric(LR_adj), p_adj=p_adj,
    components=list(k2=k2, k3=k3, k4=k4, a=a,
                    full=full, restricted=restr, gh_points=length(gh$x),
                    note=note)
  )
  class(out) <- "clogit_meta_test"
  out
}


# ---- NEW: Bartlett-type correction factor for Score (1 df) ----
._bartletttype_b_1df <- function(k2, k3, k4){
  if (!is.finite(k2) || k2 <= 0) return(NA_real_)
  # Score test Bartlett-type: b = k4/(12 k2^2) + k3^2/(8 k2^3)
  (k4 / (12 * k2^2)) + (k3^2 / (8 * k2^3))
}

# ===========================================================
# (REPLACE) 3) Score test with Bartlett-type correction (fixed mu)
# ===========================================================
SCORE_mu_fixed_Bartlett <- function(d1, n1, d2, n2, data, mu0=0){
  tab <- .build_tab_from_meta(d1, n1, d2, n2, data)
  ll_fun <- function(mu) .fixed_loglik_mu(mu, tab)
  d1 <- .nth_deriv_safe(ll_fun, mu0, n=1)
  cm <- ._bartlett_cumulants_from_ll(ll_fun, mu0)
  U  <- d1
  I  <- cm$k2
  S  <- if (is.finite(I) && I>0) (U*U)/I else NA_real_
  p_raw <- if (is.finite(S)) pchisq(S, df=1, lower.tail=FALSE) else NA_real_

  b <- ._bartletttype_b_1df(cm$k2, cm$k3, cm$k4)
  S_adj <- if (is.finite(b)) S / (1 + b) else NA_real_
  p_adj <- if (is.finite(S_adj)) pchisq(S_adj, df=1, lower.tail=FALSE) else NA_real_

  # printer compatibility
  stat_show <- if (is.finite(S_adj)) S_adj else S
  p_show    <- if (is.finite(S_adj)) p_adj else p_raw

  out <- list(
    test="Score (fixed mu) with Bartlett-type correction",
    hypothesis=sprintf("H0: mu = %.6g", mu0),
    statistic=as.numeric(stat_show),
    p_value=p_show,
    statistic_raw=as.numeric(S),
    p_raw=p_raw,
    statistic_adj=as.numeric(S_adj),
    p_adj=p_adj,
    components=list(U=U, I=I, k2=cm$k2, k3=cm$k3, k4=cm$k4, b=b,
                    note=if (!cm$ok) "derivative not stable" else NULL)
  )
  class(out) <- "clogit_meta_test"
  out
}

# ===========================================================
# (REPLACE) 4) Score test with Bartlett-type correction (RE mu)
#     (sigma fixed at restricted MLE under H0)
# ===========================================================
SCORE_mu_RE_Bartlett <- function(d1, n1, d2, n2, data, mu0=0,
                                 gh_points=30, restr_log_sigma=-1){
  tab <- .build_tab_from_meta(d1, n1, d2, n2, data)
  gh  <- .get_GH(gh_points)
  restr <- .restricted_loglik_mu(mu0, tab, gh, start_log_sigma = restr_log_sigma)

  if (!is.finite(restr$sigma_hat) || restr$sigma_hat <= 0){
    out <- list(
      test="Score (RE mu) with Bartlett-type correction",
      hypothesis=sprintf("H0: mu = %.6g", mu0),
      statistic=NA_real_, p_value=NA_real_,
      statistic_raw=NA_real_, p_raw=NA_real_,
      statistic_adj=NA_real_, p_adj=NA_real_,
      components=list(note="restricted sigma not available / non-finite")
    )
    class(out) <- "clogit_meta_test"
    return(out)
  }

  ll_fun <- function(mu) .marginal_loglik(mu, restr$sigma_hat, tab, gh)
  d1 <- .nth_deriv_safe(ll_fun, mu0, n=1)
  cm <- ._bartlett_cumulants_from_ll(ll_fun, mu0)
  U  <- d1
  I  <- cm$k2
  S  <- if (is.finite(I) && I>0) (U*U)/I else NA_real_
  p_raw <- if (is.finite(S)) pchisq(S, df=1, lower.tail=FALSE) else NA_real_

  b <- ._bartletttype_b_1df(cm$k2, cm$k3, cm$k4)
  S_adj <- if (is.finite(b)) S / (1 + b) else NA_real_
  p_adj <- if (is.finite(S_adj)) pchisq(S_adj, df=1, lower.tail=FALSE) else NA_real_

  stat_show <- if (is.finite(S_adj)) S_adj else S
  p_show    <- if (is.finite(S_adj)) p_adj else p_raw

  out <- list(
    test="Score (RE mu) with Bartlett-type correction",
    hypothesis=sprintf("H0: mu = %.6g", mu0),
    statistic=as.numeric(stat_show),
    p_value=p_show,
    statistic_raw=as.numeric(S),
    p_raw=p_raw,
    statistic_adj=as.numeric(S_adj),
    p_adj=p_adj,
    components=list(U=U, I=I, k2=cm$k2, k3=cm$k3, k4=cm$k4, b=b,
                    restricted=restr, gh_points=length(gh$x),
                    note=if (!cm$ok) "derivative not stable" else NULL)
  )
  class(out) <- "clogit_meta_test"
  out
}

# ============================================================
# END
# ============================================================





# Parametric bootstrap

# パッケージ: install.packages("BiasedUrn")
resample_hgn <- function(d1, n1, d2, n2, mu0, tau2_hat, data=NULL) {

	if(is.null(data)==FALSE){
		data <- data.frame(data)
		d1 <- data[, deparse(substitute(d1))]
		n1 <- data[, deparse(substitute(n1))]
		d2 <- data[, deparse(substitute(d2))]
		n2 <- data[, deparse(substitute(n2))]
	}
 
  m  <- d1 + d2
  K  <- length(m)
  d1s <- integer(K); d2s <- integer(K)
  for (i in seq_len(K)) {
    # ランダム効果（治療効果）の再標本化
    beta_i <- rnorm(1, mean = mu0, sd = sqrt(tau2_hat))
    OR_i   <- exp(beta_i)
    # 合計イベント mi を固定したFNCHから treated のイベント数を1回サンプル
    if (m[i] == 0L) {
      d1s[i] <- 0L
    } else if (m[i] == n2[i] + n1[i]) {
      d1s[i] <- n1[i]
    } else {
      d1s[i] <- BiasedUrn::rFNCHypergeo(1, m1 = n1[i], m2 = n2[i], n = m[i], odds = OR_i)
    }
    d2s[i] <- m[i] - d1s[i]
  }
  list(d1 = d1s, d2 = d2s)
}

LRT_mu_RE_bartbs <- function(d1,n1,d2,n2,data=NULL,mu0=0,B=1000,seed=11111,nCores=NULL){

	library("doSNOW")
	library("doParallel")

	if(is.null(data)==FALSE){
		data <- data.frame(data)
		d1 <- data[, deparse(substitute(d1))]
		n1 <- data[, deparse(substitute(n1))]
		d2 <- data[, deparse(substitute(d2))]
		n2 <- data[, deparse(substitute(n2))]
	}
  
	tau2_hat <- EST_mu_RE(d1, n1, d2, n2, mu0=mu0)$sigma_H0^2

	if(is.null(nCores))	nCores <- max(1, min(10,parallel::detectCores()-1))

	cl <- makeSOCKcluster(nCores)

	parallel::clusterSetRNGStream(cl, seed)
	registerDoSNOW(cl)

	Q6 <- foreach(b = 1:B, .combine = c, .errorhandling="remove") %dopar% {
	
		dr <- resample_hgn(d1, n1, d2, n2, mu0=mu0, tau2_hat=tau2_hat)

		datb <- data.frame(dr$d1,n1,dr$d2,n2); colnames(datb) <- c("d1","n1","d2","n2")

		mt6b <- LRT_mu_RE(datb$d1, datb$n1, datb$d2, datb$n2, mu0=mu0)

		mt6b$statistic
		
	}

	stopCluster(cl)

	mt6 <- LRT_mu_RE(d1, n1, d2, n2, mu0=mu0)
	
	T6 <- mt6$statistic/mean(Q6)
	P6 <- 1 - pchisq(T6, df=1)

	out <- list(test="LR (RE mu) with bootstrap calibration", hypothesis=sprintf("H0: mu = %.6g", mu0),
              statistic=as.numeric(T6), df=1, p_value=P6,
              components=mt6[[6]])
	class(out) <- "clogit_meta_test"
	out
	
}


EST_mu_RE_bartbs <- function(d1,n1,d2,n2,data=NULL,mu0=0,B=1000,seed=11111,nCores=NULL){

	library("doSNOW")
	library("doParallel")

	if(is.null(data)==FALSE){
		data <- data.frame(data)
		d1 <- data[, deparse(substitute(d1))]
		n1 <- data[, deparse(substitute(n1))]
		d2 <- data[, deparse(substitute(d2))]
		n2 <- data[, deparse(substitute(n2))]
	}
  
	tau2_hat <- EST_mu_RE(d1, n1, d2, n2, mu0=mu0)$sigma_H0^2

	if(is.null(nCores))	nCores <- max(1, min(10,parallel::detectCores()-1))

	cl <- makeSOCKcluster(nCores)

	parallel::clusterSetRNGStream(cl, seed)
	registerDoSNOW(cl)

	Q6 <- foreach(b = 1:B, .combine = c, .errorhandling="remove") %dopar% {
	
		dr <- resample_hgn(d1, n1, d2, n2, mu0=mu0, tau2_hat=tau2_hat)

		datb <- data.frame(dr$d1,n1,dr$d2,n2); colnames(datb) <- c("d1","n1","d2","n2")

		mt6b <- EST_mu_RE(datb$d1, datb$n1, datb$d2, datb$n2, mu0=mu0)

		mt6b$U^2
		
	}

	stopCluster(cl)

	mt6 <- EST_mu_RE(d1, n1, d2, n2, mu0=mu0)
	
	T6 <- mt6$U^2/mean(Q6)
	P6 <- 1 - pchisq(T6, df=1)

	out <- list(test="Score (RE mu) with bootstrap calibration", hypothesis=sprintf("H0: mu = %.6g", mu0),
              statistic=as.numeric(T6), df=NA, p_value=P6)
	class(out) <- "clogit_meta_test"
	out
	
}

LRT_mu_RE_boot <- function(d1,n1,d2,n2,data=NULL,mu0=0,B=1000,seed=11111,nCores=NULL){

	library("doSNOW")
	library("doParallel")

	if(is.null(data)==FALSE){
		data <- data.frame(data)
		d1 <- data[, deparse(substitute(d1))]
		n1 <- data[, deparse(substitute(n1))]
		d2 <- data[, deparse(substitute(d2))]
		n2 <- data[, deparse(substitute(n2))]
	}
  
	tau2_hat <- EST_mu_RE(d1, n1, d2, n2, mu0=mu0)$sigma_H0^2

	if(is.null(nCores))	nCores <- max(1, min(10,parallel::detectCores()-1))

	cl <- makeSOCKcluster(nCores)

	parallel::clusterSetRNGStream(cl, seed)
	registerDoSNOW(cl)

	Q6 <- foreach(b = 1:B, .combine = c, .errorhandling="remove") %dopar% {
	
		dr <- resample_hgn(d1, n1, d2, n2, mu0=mu0, tau2_hat=tau2_hat)

		datb <- data.frame(dr$d1,n1,dr$d2,n2); colnames(datb) <- c("d1","n1","d2","n2")

		mt6b <- LRT_mu_RE(datb$d1, datb$n1, datb$d2, datb$n2, mu0=mu0)

		mt6b$statistic
		
	}

	stopCluster(cl)

	mt6 <- LRT_mu_RE(d1, n1, d2, n2, mu0=mu0)
	
	T6 <- mt6$statistic
	P6 <- mean(Q6>T6)

	out <- list(test="LR (RE mu) with bootstrap test", hypothesis=sprintf("H0: mu = %.6g", mu0),
              statistic=as.numeric(T6), df=1, p_value=P6,
              components=mt6[[6]])
	class(out) <- "clogit_meta_test"
	out
	
}


EST_mu_RE_boot <- function(d1,n1,d2,n2,data=NULL,mu0=0,B=1000,seed=11111,nCores=NULL){

	library("doSNOW")
	library("doParallel")

	if(is.null(data)==FALSE){
		data <- data.frame(data)
		d1 <- data[, deparse(substitute(d1))]
		n1 <- data[, deparse(substitute(n1))]
		d2 <- data[, deparse(substitute(d2))]
		n2 <- data[, deparse(substitute(n2))]
	}
  
	tau2_hat <- EST_mu_RE(d1, n1, d2, n2, mu0=mu0)$sigma_H0^2

	if(is.null(nCores))	nCores <- max(1, min(10,parallel::detectCores()-1))

	cl <- makeSOCKcluster(nCores)

	parallel::clusterSetRNGStream(cl, seed)
	registerDoSNOW(cl)

	Q6 <- foreach(b = 1:B, .combine = c, .errorhandling="remove") %dopar% {
	
		dr <- resample_hgn(d1, n1, d2, n2, mu0=mu0, tau2_hat=tau2_hat)

		datb <- data.frame(dr$d1,n1,dr$d2,n2); colnames(datb) <- c("d1","n1","d2","n2")

		mt6b <- EST_mu_RE(datb$d1, datb$n1, datb$d2, datb$n2, mu0=mu0)

		mt6b$U^2
		
	}

	stopCluster(cl)

	mt6 <- EST_mu_RE(d1, n1, d2, n2, mu0=mu0)
	
	T6 <- mt6$U^2
	P6 <- mean(Q6>T6)

	out <- list(test="Score (RE mu) with bootstrap test", hypothesis=sprintf("H0: mu = %.6g", mu0),
              statistic=as.numeric(T6), df=NA, p_value=P6)
	class(out) <- "clogit_meta_test"
	out
	
}

