LRCI_mu_RE_bartbs <- function(d1,n1,d2,n2,data=NULL,cl=0.95,B=400,seed=11111,nCores=NULL,start.L=NULL,start.U=NULL){

	if(is.null(data)==FALSE){
		data <- data.frame(data)
		d1 <- data[, deparse(substitute(d1))]
		n1 <- data[, deparse(substitute(n1))]
		d2 <- data[, deparse(substitute(d2))]
		n2 <- data[, deparse(substitute(n2))]
	}

	alpha <- 1 - cl

	##

	mt0 <- exact_hgn_RE(d1, n1, d2, n2)

	Q0 <- mt0$mu
	Q1 <- mt0$wald_mu$ci[1]
	Q2 <- mt0$wald_mu$ci[2]

	Qd <- Q2 - Q0

	## ここだけ入れ替え：解きたい式 f(x) = 0

	f <- function(x) LRT_mu_RE_bartbs(d1, n1, d2, n2, mu0 = x,B=B,seed=seed,nCores=NULL)$p_value - alpha

######
######

if(is.null(start.L))	start.L <- (Q0 - 5*Qd)
if(is.null(start.U))	start.U <- (Q0 + 5*Qd)

message("Bisectional search for the lower limit is started.")

## 初期ブラケット [a, b] は f(a)*f(b) < 0 を満たすこと
a <- start.L; b <- Q0                 # 例：この区間に根がある
fa <- f(a); fb <- f(b)

## 安全チェック
if (!is.finite(fa) || !is.finite(fb)) stop("f(a) or f(b) not finite")
if (fa == 0) { root <- a; fm <- 0; cat("root =", root, "\n"); } else
if (fb == 0) { root <- b; fm <- 0; cat("root =", root, "\n"); } else {
  if (fa * fb > 0) stop("The signs at the endpoints match in the bisectional search; choose another initial value (start.L) where they have opposite signs.")

  tol <- 1e-4            # 許容誤差（区間幅 or |f(m)| のどちらかで判定）
  maxit <- 200L
  it <- 0L
  repeat {
    m  <- (a + b) / 2
    fm <- f(m)
    if (!is.finite(fm)) stop("f(m) is not finite (check the domain and the computation).")

    ## 収束判定：区間幅 or 関数値
    if ((b - a)/2 <= tol || abs(fm) <= tol || it >= maxit) break

    ## 区間更新（符号で半分に）
    if (fa * fm < 0) { b <- m; fb <- fm } else { a <- m; fa <- fm }
    it <- it + 1L
    message(paste0(it,"th bisectional search is completed."))  
  }
  root1 <- m
  message("")

}

######
######

message("Bisectional search for the upper limit is started.")

## 初期ブラケット [a, b] は f(a)*f(b) < 0 を満たすこと
a <- Q0; b <- start.U                 # 例：この区間に根がある
fa <- f(a); fb <- f(b)

## 安全チェック
if (!is.finite(fa) || !is.finite(fb)) stop("f(a) or f(b) not finite")
if (fa == 0) { root <- a; fm <- 0; cat("root =", root, "\n"); } else
if (fb == 0) { root <- b; fm <- 0; cat("root =", root, "\n"); } else {
  if (fa * fb > 0) stop("The signs at the endpoints match in the bisectional search; choose another initial value (start.U) where they have opposite signs.")

  tol <- 1e-4            # 許容誤差（区間幅 or |f(m)| のどちらかで判定）
  maxit <- 200L
  it <- 0L
  repeat {
    m  <- (a + b) / 2
    fm <- f(m)
    if (!is.finite(fm)) stop("f(m) is not finite (check the domain and the computation).")

    ## 収束判定：区間幅 or 関数値
    if ((b - a)/2 <= tol || abs(fm) <= tol || it >= maxit) break

    ## 区間更新（符号で半分に）
    if (fa * fm < 0) { b <- m; fb <- fm } else { a <- m; fa <- fm }
    it <- it + 1L
    message(paste0(it,"th bisectional search is completed."))  
  }
  root2 <- m
  message("")
}

######
######

A1 <- c(root1,root2)
A2 <- exp(A1)
A3 <- LRT_mu_RE_bartbs(d1, n1, d2, n2, mu0 = 0,B=B,seed=seed)$p_value

message("Confidence interval of mu by the bootstrap calibration")
list("ML estimate of mu"=Q0,"Confidence interval of log OR"=A1,"ML estimate of OR"=exp(Q0),"Confidence interval of OR"=A2,"P-value for H0: mu=0"=A3)

}



