
# barthgn package


## Bartlett Correction and Bootstrap Adjustment Methods for Likelihood-Based Inference in the Hypergeometric-Normal Random-Effects Model for Rare Event Meta-Analysis

The hypergeometric–normal random-effects model is widely used in meta-analyses of binary outcomes, providing a direct framework for modeling arm-level data from individual studies. This approach has proven particularly effective for meta-analyses involving rare events, offering relatively accurate estimation of treatment effects. However, when the number of studies is small or when many trials include zero events, large-sample approximations may break down, and the resulting inferences can be unreliable. To address these issues, this package implements higher-order asymptotic inference for the hypergeometric–normal random-effects model using Bartlett correction and bootstrap. Two improved approaches are provided: an analytic correction method and parametric bootstrap-based approaches.



## Installation

Please download "barthgn_1.1-1.tar.gz" and install it by R menu: "packages" -> "Install package(s) from local files...".

Download: [please click this link](https://github.com/nomahi/barthgn/raw/main/barthgn_1.1-1.tar.gz)

Manual: [please click this link](https://github.com/nomahi/barthgn/raw/main/barthgn_1.1-1.pdf)





```r

df <- data.frame(
  d1 = c(12,4,0,7,15),
  n1 = c(80,50,40,65,90),
  d2 = c(20,6,1,12,14),
  n2 = c(85,55,42,70,88)
)

# フィット
fitF <- exact_hgn_fixed(d1,n1,d2,n2, data=df); summary(fitF)
fitR <- exact_hgn_RE(d1,n1,d2,n2, data=df, gh_points=30); summary(fitR)

# LRT（mu） + Bartlett補正 + CI
LRT_mu_fixed(d1,n1,d2,n2, data=df, mu0=0,
             ci.level=0.95, ci.method="LRT-Bartlett") |> print()

LRT_mu_RE(d1,n1,d2,n2, data=df, mu0=0, gh_points=30,
          ci.level=0.95, ci.mu.method="LRT-Bartlett") |> print()

# スコア反転CI（固定／RE）; CF補正オプション
ESCI_fixed(d1,n1,d2,n2, data=df, level=0.95, correction="CF")
ESCI_RE(d1,n1,d2,n2, data=df, level=0.95, gh_points=30, correction="CF")
