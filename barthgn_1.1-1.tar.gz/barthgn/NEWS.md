# barthgn 1.1-1 (2025-10-13)

- first version released on GitHub
